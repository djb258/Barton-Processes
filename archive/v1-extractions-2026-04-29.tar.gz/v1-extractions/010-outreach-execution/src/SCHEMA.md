# Outreach Execution Hub - Schema Documentation

> **AUTHORITY**: CF D1 (working) / Neon PostgreSQL (vault)
> **VERIFIED**: 2026-01-25 via READ-ONLY connection
> **HUB ID**: 04.04.04
> **STATUS**: CF D1 ACTIVE / NEON VAULT

---

## Schema Overview

The Outreach Execution hub manages campaign orchestration, email sequences, send logging, and engagement tracking. It also owns the BIT (Buyer Intent Tracker) scoring system and coordinates all outreach program context.

## Primary Tables

| Schema | Table | Purpose |
|--------|-------|---------|
| `outreach` | `outreach` | Root outreach context records |
| `outreach` | `outreach_excluded` | **EXCLUSION TABLE** - All non-commercial/invalid records |
| `outreach` | `outreach_archive` | Archived outreach records |
| `outreach` | `outreach_orphan_archive` | Orphaned records with invalid sovereign_id |
| `outreach` | `outreach_errors` | Outreach pipeline errors |
| `outreach` | `campaigns` | Campaign definitions |
| `outreach` | `sequences` | Email sequence templates |
| `outreach` | `send_log` | Email send tracking |
| `outreach` | `engagement_events` | All engagement events |
| `outreach` | `bit_scores` | BIT scores by outreach |
| `outreach` | `bit_signals` | BIT signal events |
| `outreach` | `bit_errors` | BIT processing errors |
| `outreach` | `hub_registry` | Hub definitions |
| `outreach` | `manual_overrides` | **KILL SWITCH** - Manual override controls |
| `outreach` | `override_audit_log` | **KILL SWITCH** - Override audit trail |
| `cl` | `company_identity` | CL Authority Registry (identity pointers) |
| `cl` | `company_domains` | CL domain records (1:N) |
| `bit` | `authorization_log` | BIT authorization requests |
| `bit` | `movement_events` | BIT movement detection |
| `bit` | `phase_state` | BIT phase state per company |
| `bit` | `proof_lines` | BIT authorization proof lines |

---

## Entity Relationship Diagram

```mermaid
erDiagram
    CL_COMPANY_IDENTITY ||--o{ OUTREACH_OUTREACH : "sovereign_id"
    CL_COMPANY_IDENTITY ||--o{ CL_COMPANY_DOMAINS : "company_unique_id"

    OUTREACH_OUTREACH ||--o{ OUTREACH_COMPANY_TARGET : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_PEOPLE : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_DOL : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_BIT_SCORES : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_BIT_SIGNALS : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_BIT_ERRORS : "outreach_id"
    OUTREACH_OUTREACH ||--o{ OUTREACH_OUTREACH_ERRORS : "outreach_id"

    OUTREACH_CAMPAIGNS ||--o{ OUTREACH_SEQUENCES : "campaign_id"
    OUTREACH_CAMPAIGNS ||--o{ OUTREACH_SEND_LOG : "campaign_id"
    OUTREACH_SEQUENCES ||--o{ OUTREACH_SEND_LOG : "sequence_id"

    OUTREACH_COMPANY_TARGET ||--o{ OUTREACH_SEND_LOG : "target_id"
    OUTREACH_COMPANY_TARGET ||--o{ OUTREACH_ENGAGEMENT_EVENTS : "target_id"
    OUTREACH_PEOPLE ||--o{ OUTREACH_SEND_LOG : "person_id"
    OUTREACH_PEOPLE ||--o{ OUTREACH_ENGAGEMENT_EVENTS : "person_id"

    OUTREACH_MANUAL_OVERRIDES ||--o{ OUTREACH_OVERRIDE_AUDIT_LOG : "override_id"
    OUTREACH_HUB_REGISTRY ||--o{ OUTREACH_COMPANY_HUB_STATUS : "hub_id"

    CL_COMPANY_IDENTITY {
        uuid sovereign_company_id PK "Minted by CL (IMMUTABLE)"
        uuid company_unique_id UK "Legacy ID"
        text company_name
        text company_domain
        text canonical_name
        text identity_status "PENDING|PASS|FAIL"
        int identity_pass
        text eligibility_status
        text exclusion_reason
        uuid outreach_id "WRITE-ONCE (minted by Outreach)"
        uuid sales_process_id "WRITE-ONCE (minted by Sales)"
        uuid client_id "WRITE-ONCE (minted by Client)"
        timestamptz outreach_attached_at
        timestamptz created_at
    }

    CL_COMPANY_DOMAINS {
        uuid domain_id PK
        uuid company_unique_id FK
        text domain
        text domain_health
        boolean mx_present
        int domain_name_confidence
        timestamp checked_at
    }

    OUTREACH_OUTREACH {
        uuid outreach_id PK "Minted here, registered in CL"
        uuid sovereign_id FK "FK to cl.company_identity.sovereign_company_id"
        varchar domain
        timestamptz created_at
        timestamptz updated_at
    }

    OUTREACH_CAMPAIGNS {
        uuid campaign_id PK
        varchar campaign_name
        varchar campaign_type
        varchar campaign_status
        int target_bit_score_min
        varchar target_outreach_state
        int daily_send_limit
        int total_send_limit
        int total_targeted
        int total_sent
        int total_opened
        int total_clicked
        int total_replied
        date start_date
        date end_date
    }

    OUTREACH_SEQUENCES {
        uuid sequence_id PK
        uuid campaign_id FK
        varchar sequence_name
        int sequence_order
        text subject_template
        text body_template
        varchar template_type
        int delay_days
        int delay_hours
        varchar send_time_preference
        varchar sequence_status
    }

    OUTREACH_SEND_LOG {
        uuid send_id PK
        uuid campaign_id FK
        uuid sequence_id FK
        uuid person_id FK
        uuid target_id FK
        text company_unique_id
        varchar email_to
        text email_subject
        int sequence_step
        varchar send_status
        timestamp scheduled_at
        timestamp sent_at
        timestamp delivered_at
        timestamp bounced_at
        timestamp opened_at
        timestamp clicked_at
        timestamp replied_at
        int open_count
        int click_count
        text error_message
        int retry_count
    }

    OUTREACH_ENGAGEMENT_EVENTS {
        uuid event_id PK
        uuid person_id FK
        uuid target_id FK
        uuid outreach_id FK
        text company_unique_id
        enum event_type
        text event_subtype
        timestamp event_ts
        text source_system
        text source_campaign_id
        jsonb metadata
        boolean is_processed
        boolean triggered_transition
        enum transition_to_state
        varchar event_hash
        boolean is_duplicate
    }

    OUTREACH_BIT_SCORES {
        uuid outreach_id PK
        numeric score
        varchar score_tier
        int signal_count
        numeric people_score
        numeric dol_score
        numeric blog_score
        numeric talent_flow_score
        timestamp last_signal_at
        timestamp last_scored_at
    }

    OUTREACH_BIT_SIGNALS {
        uuid signal_id PK
        uuid outreach_id FK
        varchar signal_type
        numeric signal_impact
        varchar source_spoke
        uuid correlation_id
        uuid process_id
        jsonb signal_metadata
        int decay_period_days
        numeric decayed_impact
        timestamp signal_timestamp
    }

    OUTREACH_BIT_ERRORS {
        uuid error_id PK
        uuid outreach_id FK
        varchar pipeline_stage
        varchar failure_code
        text blocking_reason
        varchar severity
        boolean retry_allowed
        uuid correlation_id
    }

    OUTREACH_MANUAL_OVERRIDES {
        uuid override_id PK
        text company_unique_id
        enum override_type "HARD_FAIL|SKIP|etc"
        text reason
        jsonb metadata
        timestamptz created_at
        text created_by
        timestamptz expires_at
        boolean is_active
        timestamptz deactivated_at
        text deactivated_by
        text deactivation_reason
    }

    OUTREACH_OVERRIDE_AUDIT_LOG {
        uuid audit_id PK
        text company_unique_id
        uuid override_id FK
        text action
        enum override_type
        jsonb old_value
        jsonb new_value
        text performed_by
        timestamptz performed_at
    }

    OUTREACH_HUB_REGISTRY {
        varchar hub_id PK
        varchar hub_name
        varchar doctrine_id
        varchar classification "ANCHOR|SUB-HUB"
        boolean gates_completion
        int waterfall_order
        varchar core_metric
        numeric metric_healthy_threshold
        numeric metric_critical_threshold
        text description
        timestamptz created_at
        timestamptz updated_at
    }

    BIT_AUTHORIZATION_LOG {
        uuid log_id PK
        text company_unique_id
        text requested_action
        int requested_band
        boolean authorized
        int actual_band
        text denial_reason
        text proof_id FK
        boolean proof_valid
        timestamptz requested_at
        text requested_by
        text correlation_id
    }

    BIT_PHASE_STATE {
        text company_unique_id PK
        int current_band
        text phase_status "SILENT|EMERGING|ACTIVE|STASIS"
        boolean dol_active
        boolean people_active
        boolean blog_active
        text primary_pressure
        int aligned_domains
        timestamptz last_movement_at
        timestamptz last_band_change_at
        timestamptz updated_at
    }

    BIT_PROOF_LINES {
        text proof_id PK
        text company_unique_id
        int band
        text pressure_class
        array sources
        jsonb evidence
        array movement_ids
        text human_readable
        timestamptz generated_at
        timestamptz valid_until
        text generated_by
    }
```

---

## Table Details

### outreach.outreach

Root outreach context binding company identity to outreach program.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `outreach_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `sovereign_id` | uuid | NOT NULL | - | FK to cl.company_identity |
| `domain` | varchar | NULL | - | Company domain |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Last update time |

### outreach.outreach_excluded (EXCLUSION TABLE)

**THE SINGULAR EXCLUSION TABLE** - All records that should NOT be in the active outreach spine.

This table consolidates ALL exclusions from:
- Non-commercial entities (churches, schools, hospitals, government)
- CL PENDING records (not yet PASS)
- CL FAIL records
- Invalid sovereign_ids (NOT_IN_CL)
- Data quality issues (duplicate domains, bad mappings)

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `outreach_id` | uuid | NOT NULL | - | Primary key (was in outreach.outreach) |
| `company_name` | text | NULL | - | Company name from CL |
| `domain` | text | NULL | - | Company domain |
| `exclusion_reason` | text | NULL | - | Why excluded (see categories below) |
| `sovereign_id` | uuid | NULL | - | Original sovereign_id reference |
| `cl_status` | text | NULL | - | CL identity_status at time of exclusion |
| `excluded_by` | text | NULL | - | What process excluded this record |
| `excluded_at` | timestamptz | NULL | now() | When excluded |
| `created_at` | timestamptz | NULL | - | Original creation time |
| `updated_at` | timestamptz | NULL | - | Original update time |

**Exclusion Reason Categories:**

| Reason | Description |
|--------|-------------|
| `CL_NOT_PASS: identity_status=PENDING` | CL record exists but not yet verified |
| `CL_FAIL: identity_status=FAIL` | CL explicitly marked as FAIL |
| `NOT_IN_CL: sovereign_id does not exist` | Invalid sovereign_id reference |
| `NON_COMMERCIAL_TLD: .gov` | Government entity |
| `NON_COMMERCIAL_TLD: .edu` | Educational institution |
| `NON_COMMERCIAL_TLD: .org` | Non-profit organization |
| `NON_COMMERCIAL_TLD: .church` | Religious organization |
| `NON_COMMERCIAL_KEYWORD: church` | Church keyword in name |
| `NON_COMMERCIAL_KEYWORD: school` | School keyword in name |
| `NON_COMMERCIAL_KEYWORD: hospital` | Healthcare facility |
| `DUPLICATE_DOMAIN` | Domain already exists in outreach.outreach |
| `DATA_QUALITY` | Data quality issue (bad mapping, etc.) |

**Query to check exclusion distribution:**

```sql
SELECT exclusion_reason, COUNT(*)
FROM outreach.outreach_excluded
GROUP BY exclusion_reason
ORDER BY COUNT(*) DESC;
```

### outreach.campaigns

Campaign definitions for outreach sequences.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `campaign_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `campaign_name` | varchar | NOT NULL | - | Campaign name |
| `campaign_type` | varchar | NOT NULL | 'cold' | Type (cold, warm, nurture) |
| `campaign_status` | varchar | NOT NULL | 'draft' | Status (draft, active, paused, completed) |
| `target_bit_score_min` | integer | NULL | 25 | Minimum BIT score to target |
| `target_outreach_state` | varchar | NULL | - | Target lifecycle state |
| `daily_send_limit` | integer | NULL | 100 | Max sends per day |
| `total_send_limit` | integer | NULL | - | Max total sends |
| `total_targeted` | integer | NOT NULL | 0 | Count targeted |
| `total_sent` | integer | NOT NULL | 0 | Count sent |
| `total_opened` | integer | NOT NULL | 0 | Count opened |
| `total_clicked` | integer | NOT NULL | 0 | Count clicked |
| `total_replied` | integer | NOT NULL | 0 | Count replied |
| `start_date` | date | NULL | - | Campaign start |
| `end_date` | date | NULL | - | Campaign end |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Last update time |

### outreach.sequences

Email sequence templates within campaigns.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `sequence_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `campaign_id` | uuid | NULL | - | FK to campaigns |
| `sequence_name` | varchar | NOT NULL | - | Sequence name |
| `sequence_order` | integer | NOT NULL | 1 | Order in campaign |
| `subject_template` | text | NULL | - | Email subject template |
| `body_template` | text | NULL | - | Email body template |
| `template_type` | varchar | NULL | 'email' | Type (email, linkedin, etc) |
| `delay_days` | integer | NOT NULL | 0 | Days delay from previous |
| `delay_hours` | integer | NOT NULL | 0 | Hours delay from previous |
| `send_time_preference` | varchar | NULL | 'business_hours' | Preferred send time |
| `sequence_status` | varchar | NOT NULL | 'active' | Status |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Last update time |

### outreach.send_log

Individual email send tracking.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `send_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `campaign_id` | uuid | NULL | - | FK to campaigns |
| `sequence_id` | uuid | NULL | - | FK to sequences |
| `person_id` | uuid | NULL | - | FK to people |
| `target_id` | uuid | NULL | - | FK to company_target |
| `company_unique_id` | text | NULL | - | Company reference |
| `email_to` | varchar | NOT NULL | - | Recipient email |
| `email_subject` | text | NULL | - | Email subject |
| `sequence_step` | integer | NOT NULL | 1 | Step in sequence |
| `send_status` | varchar | NOT NULL | 'pending' | Status |
| `scheduled_at` | timestamptz | NULL | - | Scheduled time |
| `sent_at` | timestamptz | NULL | - | Actual send time |
| `delivered_at` | timestamptz | NULL | - | Delivery time |
| `bounced_at` | timestamptz | NULL | - | Bounce time |
| `opened_at` | timestamptz | NULL | - | First open time |
| `clicked_at` | timestamptz | NULL | - | First click time |
| `replied_at` | timestamptz | NULL | - | Reply time |
| `open_count` | integer | NOT NULL | 0 | Total opens |
| `click_count` | integer | NOT NULL | 0 | Total clicks |
| `error_message` | text | NULL | - | Error if failed |
| `retry_count` | integer | NOT NULL | 0 | Retry attempts |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Last update time |

### outreach.bit_scores

BIT (Buyer Intent Tracker) scores by outreach.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `outreach_id` | uuid | NOT NULL | - | PK, FK to outreach.outreach |
| `score` | numeric | NOT NULL | 0 | Total BIT score |
| `score_tier` | varchar | NOT NULL | 'COLD' | Score tier (COLD, WARM, HOT, BURNING) |
| `signal_count` | integer | NOT NULL | 0 | Total signals received |
| `people_score` | numeric | NOT NULL | 0 | Score from people signals |
| `dol_score` | numeric | NOT NULL | 0 | Score from DOL signals |
| `blog_score` | numeric | NOT NULL | 0 | Score from blog signals |
| `talent_flow_score` | numeric | NOT NULL | 0 | Score from talent flow signals |
| `last_signal_at` | timestamptz | NULL | - | Last signal timestamp |
| `last_scored_at` | timestamptz | NULL | - | Last scoring timestamp |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Last update time |

### outreach.bit_signals

Individual BIT signal events.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `signal_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `outreach_id` | uuid | NOT NULL | - | FK to outreach.outreach |
| `signal_type` | varchar | NOT NULL | - | Signal type |
| `signal_impact` | numeric | NOT NULL | - | Impact on score |
| `source_spoke` | varchar | NOT NULL | - | Source spoke (people, dol, blog) |
| `correlation_id` | uuid | NOT NULL | - | Correlation ID for tracing |
| `process_id` | uuid | NULL | - | Process ID |
| `signal_metadata` | jsonb | NULL | - | Additional metadata |
| `decay_period_days` | integer | NOT NULL | 90 | Days until decay |
| `decayed_impact` | numeric | NULL | - | Current decayed impact |
| `signal_timestamp` | timestamptz | NOT NULL | now() | Signal timestamp |
| `processed_at` | timestamptz | NULL | - | Processing timestamp |
| `created_at` | timestamptz | NOT NULL | now() | Record creation time |

---

## Foreign Key Relationships

| Source Table | Source Column | Target Table | Target Column |
|--------------|---------------|--------------|---------------|
| cl.company_domains | company_unique_id | cl.company_identity | company_unique_id |
| outreach.bit_errors | outreach_id | outreach.outreach | outreach_id |
| outreach.bit_scores | outreach_id | outreach.outreach | outreach_id |
| outreach.bit_signals | outreach_id | outreach.outreach | outreach_id |
| outreach.company_target | outreach_id | outreach.outreach | outreach_id |
| outreach.dol | outreach_id | outreach.outreach | outreach_id |
| outreach.engagement_events | person_id | outreach.people | person_id |
| outreach.engagement_events | target_id | outreach.company_target | target_id |
| outreach.engagement_events | outreach_id | outreach.outreach | outreach_id |
| outreach.people | outreach_id | outreach.outreach | outreach_id |
| outreach.people | target_id | outreach.company_target | target_id |
| outreach.send_log | campaign_id | outreach.campaigns | campaign_id |
| outreach.send_log | sequence_id | outreach.sequences | sequence_id |
| outreach.send_log | person_id | outreach.people | person_id |
| outreach.send_log | target_id | outreach.company_target | target_id |
| outreach.sequences | campaign_id | outreach.campaigns | campaign_id |
| outreach.override_audit_log | override_id | outreach.manual_overrides | override_id |

---

### outreach.manual_overrides (KILL SWITCH)

Manual override controls for marketing eligibility. v1.0 FROZEN component.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `override_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `company_unique_id` | text | NOT NULL | - | Company identifier |
| `override_type` | enum | NOT NULL | - | Override type (HARD_FAIL, SKIP, etc) |
| `reason` | text | NOT NULL | - | Human-readable reason |
| `metadata` | jsonb | NULL | '{}' | Additional context |
| `created_at` | timestamptz | NOT NULL | now() | Creation time |
| `created_by` | text | NOT NULL | CURRENT_USER | Who created |
| `expires_at` | timestamptz | NULL | - | Optional expiration |
| `is_active` | boolean | NOT NULL | true | Active flag |
| `deactivated_at` | timestamptz | NULL | - | Deactivation time |
| `deactivated_by` | text | NULL | - | Who deactivated |
| `deactivation_reason` | text | NULL | - | Why deactivated |

### outreach.override_audit_log (KILL SWITCH AUDIT)

Immutable audit trail for all override actions.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `audit_id` | uuid | NOT NULL | gen_random_uuid() | Primary key |
| `company_unique_id` | text | NOT NULL | - | Company identifier |
| `override_id` | uuid | NULL | - | FK to manual_overrides |
| `action` | text | NOT NULL | - | Action taken |
| `override_type` | enum | NULL | - | Override type |
| `old_value` | jsonb | NULL | - | Previous state |
| `new_value` | jsonb | NULL | - | New state |
| `performed_by` | text | NOT NULL | CURRENT_USER | Actor |
| `performed_at` | timestamptz | NOT NULL | now() | Timestamp |

### outreach.hub_registry

Waterfall order and health metrics for all hubs.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `hub_id` | varchar(50) | NOT NULL | - | Primary key |
| `hub_name` | varchar(100) | NOT NULL | - | Display name |
| `doctrine_id` | varchar(20) | NOT NULL | - | Doctrine reference |
| `classification` | varchar(20) | NOT NULL | - | Type: ANCHOR, SUB-HUB |
| `gates_completion` | boolean | NOT NULL | false | Blocks downstream? |
| `waterfall_order` | integer | NOT NULL | - | Execution order |
| `core_metric` | varchar(50) | NOT NULL | - | Key metric name |
| `metric_healthy_threshold` | numeric | NULL | - | Green threshold |
| `metric_critical_threshold` | numeric | NULL | - | Red threshold |
| `description` | text | NULL | - | Purpose |
| `created_at` | timestamptz | NOT NULL | now() | Creation time |
| `updated_at` | timestamptz | NOT NULL | now() | Update time |

---

## BIT Score Tiers

| Tier | Score Range | Description |
|------|-------------|-------------|
| COLD | 0-24 | No significant intent signals |
| WARM | 25-49 | Some intent signals detected |
| HOT | 50-74 | Strong intent signals |
| BURNING | 75+ | Very high intent, prioritize outreach |

---

## Engagement Event Types

| Event Type | Description |
|------------|-------------|
| `email_open` | Email was opened |
| `email_click` | Link in email clicked |
| `email_reply` | Recipient replied |
| `email_bounce` | Email bounced |
| `linkedin_view` | LinkedIn profile viewed |
| `website_visit` | Website visit detected |
| `form_submit` | Form submission |

---

---

## Cascade Cleanup Documentation

**Reference**: `docs/reports/OUTREACH_CASCADE_CLEANUP_REPORT_2026-01-29.md`

### Table Ownership (SPINE OWNER)

This hub owns the **operational spine** (`outreach.outreach`). All other sub-hubs FK to this table.

| Table | Purpose | Cascade Order |
|-------|---------|---------------|
| `outreach.outreach` | **SPINE** - Root records | DELETE LAST |
| `outreach.outreach_archive` | Archived spine records | Receives orphaned records |
| `outreach.outreach_orphan_archive` | Unfixable orphans | Receives orphans with invalid sovereign_id |
| `outreach.campaigns` | Campaign definitions | DELETE early |
| `outreach.sequences` | Email sequences | DELETE after send_log |
| `outreach.send_log` | Send tracking | DELETE FIRST |
| `outreach.bit_scores` | BIT scores | DELETE after bit_signals |
| `outreach.bit_signals` | BIT signal events | DELETE early |
| `outreach.manual_overrides` | Kill switch overrides | DELETE early |

### Cascade Deletion Order (AUTHORITATIVE)

This hub defines the deletion order for all sub-hubs:

```
1. outreach.send_log          (FK: person_id, target_id, campaign_id, sequence_id)
2. outreach.sequences         (FK: campaign_id)
3. outreach.campaigns         (standalone)
4. outreach.manual_overrides  (FK: outreach_id)
5. outreach.bit_signals       (FK: outreach_id)
6. outreach.bit_scores        (FK: outreach_id)
7. outreach.blog              (FK: outreach_id) → Blog Hub
8. people.people_master       (FK: company_slot) → People Hub
9. people.company_slot        (FK: outreach_id) → People Hub
10. outreach.people           (FK: outreach_id) → People Hub
11. outreach.dol              (FK: outreach_id) → DOL Hub
12. outreach.company_target   (FK: outreach_id) → Company Target Hub
13. outreach.outreach         (SPINE - deleted LAST)
```

### Archive-Before-Delete Pattern

Before deleting spine records:

```sql
-- 1. Archive to outreach_archive
INSERT INTO outreach.outreach_archive
SELECT *, 'CL_INELIGIBLE_CASCADE' as archive_reason, NOW() as archived_at
FROM outreach.outreach
WHERE outreach_id IN (SELECT outreach_id FROM orphan_list);

-- 2. For orphans with invalid sovereign_id, use outreach_orphan_archive
INSERT INTO outreach.outreach_orphan_archive
SELECT outreach_id, sovereign_id, created_at, updated_at, domain,
       'INVALID_SOVEREIGN_ID' as archive_reason, NOW() as archived_at
FROM outreach.outreach o
WHERE NOT EXISTS (SELECT 1 FROM cl.company_identity ci WHERE ci.outreach_id = o.outreach_id)
  AND NOT EXISTS (SELECT 1 FROM cl.company_identity ci2 WHERE ci2.sovereign_company_id = o.sovereign_id);

-- 3. Delete spine last
DELETE FROM outreach.outreach
WHERE outreach_id IN (SELECT outreach_id FROM orphan_list);
```

### Post-Cleanup State (2026-01-29)

| Table | Records | Notes |
|-------|---------|-------|
| outreach.outreach | **42,192** | ALIGNED with CL |
| outreach.outreach_archive | — | Contains excluded records |
| outreach.outreach_orphan_archive | 2,709 | Unfixable orphans |
| outreach.bit_scores | 13,226 | BIT-scored records |
| outreach.campaigns | — | Campaign definitions |
| outreach.send_log | — | Send history |

### Alignment Verification Query

Run this to verify CL-Outreach alignment:

```sql
SELECT
    'cl.company_identity' as source,
    COUNT(*) as with_outreach_id
FROM cl.company_identity
WHERE outreach_id IS NOT NULL
UNION ALL
SELECT
    'outreach.outreach' as source,
    COUNT(*) as count
FROM outreach.outreach;

-- Expected: Both counts should match (42,192 = 42,192)
```

### Cleanup Trigger

This hub's data (and all sub-hub data) is cleaned when:
1. CL marks company as `INELIGIBLE` (eligibility_status)
2. CL moves company to `cl.company_identity_excluded`
3. Outreach cascade cleanup runs via `OUTREACH_CASCADE_CLEANUP.prompt.md`

### Golden Rule (LOCKED)

```
IF outreach_id IS NULL:
    STOP. DO NOT PROCEED.
    1. Mint outreach_id in outreach.outreach (operational spine)
    2. Write outreach_id ONCE to cl.company_identity (authority registry)
    3. If CL write fails (already claimed) → HARD FAIL

ALIGNMENT RULE:
outreach.outreach count = cl.company_identity (outreach_id NOT NULL) count
Current: 42,192 = 42,192 ✓ ALIGNED
```

---

*Generated from Neon PostgreSQL vault via READ-ONLY connection*
*Last verified: 2026-02-02*
*ERD Sync: NEON_SCHEMA_REFERENCE_FOR_ERD.md*

---

## Dropped Tables (2026-02-20 -- Table Consolidation)

The following tables were **dropped** during database consolidation. All had 0 rows at time of drop.
Recreatable from migration files if needed.

| Table | Reason | Migration Source |
|-------|--------|-----------------|
| `outreach.campaigns` | 0 rows, never used in production | `migrations/2026-01-13-outreach-execution-complete.sql` |
| `outreach.sequences` | 0 rows, never used in production | `migrations/2026-01-13-outreach-execution-complete.sql` |
| `outreach.send_log` | 0 rows, never used in production | `migrations/2026-01-13-outreach-execution-complete.sql` |
| `outreach.engagement_events` | 0 rows, never used in production | `migrations/0003_create_engagement_events.sql` |
| `outreach.manual_overrides` | 0 rows, kill switch never activated | `migrations/2026-01-19-kill-switches.sql` |
| `outreach.override_audit_log` | 0 rows, kill switch never activated | `migrations/2026-01-19-kill-switches.sql` |
| `outreach.bit_signals` | 0 rows, BIT signal ingestion not yet active | `migrations/2026-01-25-bit-v2-phase1-schema.sql` |
| `outreach.outreach_errors` | 0 rows, no pipeline errors recorded | See `migrations/` directory |
| `outreach.pipeline_audit_log` | 0 rows, audit pipeline not yet active | See `migrations/` directory |
| `bit.authorization_log` | 0 rows, BIT authorization not yet active | `migrations/2026-01-25-bit-v2-phase1-schema.sql` |
| `bit.phase_state` | 0 rows, BIT phase tracking not yet active | `migrations/2026-01-25-bit-v2-phase1-schema.sql` |
| `bit.proof_lines` | 0 rows, BIT proof system not yet active | `migrations/2026-01-25-bit-v2-phase1-schema.sql` |
| `bit.movement_events` | 0 rows, BIT movement detection not yet active | `migrations/2026-01-25-bit-v2-phase1-schema.sql` |
| `outreach.bit_input_history` | 0 rows, BIT input tracking not yet active | See `migrations/` directory |

**Note:** The `outreach.bit_scores` and `outreach.bit_errors` tables were NOT dropped (they contain data).
